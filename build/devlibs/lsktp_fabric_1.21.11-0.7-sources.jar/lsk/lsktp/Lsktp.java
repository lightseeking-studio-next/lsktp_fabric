package lsk.lsktp;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.command.argument.DimensionArgumentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class Lsktp implements ModInitializer {

    private static final SimpleCommandExceptionType INVALID_COORD = new SimpleCommandExceptionType(Text.literal("无效的坐标格式"));

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("lsktp")
                    .then(CommandManager.argument("x", StringArgumentType.word())
                            .then(CommandManager.argument("y", StringArgumentType.word())
                                    .then(CommandManager.argument("z", StringArgumentType.word())
                                            .executes(context -> execute_command(context.getSource(), context))
                                    )
                            )
                    )
            );
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("lsktp")
                    .then(CommandManager.argument("d", DimensionArgumentType.dimension())
                            .then(CommandManager.argument("x", StringArgumentType.word())
                                    .then(CommandManager.argument("y", StringArgumentType.word())
                                            .then(CommandManager.argument("z", StringArgumentType.word())
                                                    .executes(context -> execute(context.getSource(), context))
                                            )
                                    )
                            )
                    )
            );
        });
    }

    private static double parseCoordinate(String input, double current) throws CommandSyntaxException {
        if (input.equals("~")) {
            return current;
        }
        if (input.startsWith("~")) {
            try {
                return current + Double.parseDouble(input.substring(1));
            } catch (NumberFormatException e) {
                throw INVALID_COORD.create();
            }
        }
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            throw INVALID_COORD.create();
        }
    }

    private static int findSafeY(ServerWorld world, double x, double z) {
        BlockPos blockPos = new BlockPos((int) x, 0, (int) z);
        int maxY = world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, blockPos);
        int minY = world.getBottomY();

        // 从高处向下搜索第一个安全的 Y 坐标
        for (int y = maxY; y >= minY; y--) {
            BlockPos pos = new BlockPos((int) x, y, (int) z);
            BlockState above = world.getBlockState(pos.up());
            BlockState at = world.getBlockState(pos);
            BlockState below = world.getBlockState(pos.down());

            // 检查上方是空气，当前位置是固体或流体，下方是固体
            boolean aboveAir = above.isAir();
            boolean atSolidOrFluid = !at.isAir() || at.getBlock() instanceof FluidBlock;
            boolean belowSolid = !below.isAir();

            if (aboveAir && atSolidOrFluid && belowSolid) {
                return y + 1; // 返回安全的传送位置（在固体方块上方）
            }
        }
        return minY; // 如果找不到安全位置，返回最低点
    }

    static int execute_command(ServerCommandSource source, CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        var entity = source.getPlayer();
        if (entity == null) {
            source.sendError(Text.literal("需玩家执行！"));
            return 0;
        }

        String xStr = StringArgumentType.getString(context, "x");
        String yStr = StringArgumentType.getString(context, "y");
        String zStr = StringArgumentType.getString(context, "z");

        double x = parseCoordinate(xStr, entity.getX());
        double z = parseCoordinate(zStr, entity.getZ());
        double y;

        ServerWorld world = source.getWorld();

        // 检查 y 是否使用 ~ 符号
        if (yStr.equals("~")) {
            y = findSafeY(world, x, z);
        } else if (yStr.startsWith("~")) {
            y = parseCoordinate(yStr, entity.getY());
        } else {
            y = parseCoordinate(yStr, entity.getY());
        }

        entity.teleport(world, x, y, z, new java.util.HashSet<>(), entity.getYaw(), entity.getPitch(), false);
        source.sendFeedback(() -> Text.literal("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }

    private static int execute(ServerCommandSource source, CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        var player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("需玩家执行！"));
            return 0;
        }

        String xStr = StringArgumentType.getString(context, "x");
        String yStr = StringArgumentType.getString(context, "y");
        String zStr = StringArgumentType.getString(context, "z");

        double x = parseCoordinate(xStr, player.getX());
        double z = parseCoordinate(zStr, player.getZ());
        double y;

        ServerWorld dimension = DimensionArgumentType.getDimensionArgument(context, "d");

        // 检查 y 是否使用 ~ 符号
        if (yStr.equals("~")) {
            y = findSafeY(dimension, x, z);
        } else if (yStr.startsWith("~")) {
            y = parseCoordinate(yStr, player.getY());
        } else {
            y = parseCoordinate(yStr, player.getY());
        }

        player.teleport(dimension, x, y, z, new java.util.HashSet<>(), player.getYaw(), player.getPitch(), false);
        source.sendFeedback(() -> Text.literal("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }
}