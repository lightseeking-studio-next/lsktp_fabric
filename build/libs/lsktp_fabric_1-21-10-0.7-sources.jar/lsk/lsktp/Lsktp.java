package lsk.lsktp;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2181;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.HashSet;

public class Lsktp implements ModInitializer {

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("x", DoubleArgumentType.doubleArg())
                            .then(class_2170.method_9244("y", DoubleArgumentType.doubleArg())
                                    .then(class_2170.method_9244("z", DoubleArgumentType.doubleArg())
                                            //   .executes(context -> teleportPlayer(context))
                                            .executes(context ->execute_command(context.getSource(),context))
                                    )
                            )
                    )
                    .requires(source -> source.method_9259(0)) // 设置权限等级
            );
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("d", class_2181.method_9288())
                            .then(class_2170.method_9244("x", DoubleArgumentType.doubleArg())
                                    .then(class_2170.method_9244("y", DoubleArgumentType.doubleArg())
                                            .then(class_2170.method_9244("z", DoubleArgumentType.doubleArg())
                                                    //   .executes(context -> teleportPlayer(context))
                                                    .executes(context ->execute(context.getSource(),context))
                                            )
                                    )
                            )
                    )
                    .requires(source -> source.method_9259(0)) // 设置权限等级
            );
        });


    }
    static int execute_command(class_2168 Source, CommandContext<class_2168> context){
        class_1297 entity =  Source.method_44023() ;

        double x = DoubleArgumentType.getDouble(context, "x");
        double y = DoubleArgumentType.getDouble(context, "y");
        double z = DoubleArgumentType.getDouble(context, "z");

        entity.method_48105(Source.method_9225(),x , y, z, new HashSet<>(), entity.method_36454(), entity.method_36455(),false);
        context.getSource().method_9226(() -> class_2561.method_43470("传送至 " + x + ", " + y + ", " + z), false);

        return 1;
    }
    private static int execute(class_2168 Source, CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        class_1297 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43471("需玩家执行！"));
            return 0;
        }
        double x = DoubleArgumentType.getDouble(context, "x");
        double y = DoubleArgumentType.getDouble(context, "y");
        double z = DoubleArgumentType.getDouble(context, "z");
        class_3218 d = class_2181.method_9289(context, "d");

        //RegistryKey<World> registryKey;

        //registryKey = player.getEntityWorld().getRegistryKey();

        if (d != null) {
            player.method_48105(d, x, y, z, new HashSet<>(), player.method_36454(), player.method_36455(), false);

            context.getSource().method_9226(() -> class_2561.method_43470("传送至 "+ x + ", " + y + ", " + z), false);

            return 1;
        }


        return 1;
    }
}
