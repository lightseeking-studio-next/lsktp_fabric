package lsk.lsktp;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2181;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class Lsktp implements ModInitializer {

    private static final SimpleCommandExceptionType INVALID_COORD = new SimpleCommandExceptionType(class_2561.method_43470("无效的坐标格式"));

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("x", StringArgumentType.word())
                            .then(class_2170.method_9244("y", StringArgumentType.word())
                                    .then(class_2170.method_9244("z", StringArgumentType.word())
                                            .executes(context -> execute_command(context.getSource(), context))
                                    )
                            )
                    )
            );
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("d", class_2181.method_9288())
                            .then(class_2170.method_9244("x", StringArgumentType.word())
                                    .then(class_2170.method_9244("y", StringArgumentType.word())
                                            .then(class_2170.method_9244("z", StringArgumentType.word())
                                                    .executes(context -> execute(context.getSource(), context))
                                            )
                                    )
                            )
                    )
            );
        });
    }

    private static double parseCoordinate(String input, double current) throws CommandSyntaxException {
        if (input.equals("~")) {
            return current;
        }
        if (input.startsWith("~")) {
            try {
                return current + Double.parseDouble(input.substring(1));
            } catch (NumberFormatException e) {
                throw INVALID_COORD.create();
            }
        }
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            throw INVALID_COORD.create();
        }
    }

    private static int findSafeY(class_3218 world, double x, double z) {
        class_2338 blockPos = new class_2338((int) x, 0, (int) z);
        int maxY = world.method_67393(net.minecraft.class_2902.class_2903.field_13197, blockPos);
        int minY = world.method_31607();

        // 从高处向下搜索第一个安全的 Y 坐标
        for (int y = maxY; y >= minY; y--) {
            class_2338 pos = new class_2338((int) x, y, (int) z);
            class_2680 above = world.method_8320(pos.method_10084());
            class_2680 at = world.method_8320(pos);
            class_2680 below = world.method_8320(pos.method_10074());

            // 检查上方是空气，当前位置是固体或流体，下方是固体
            boolean aboveAir = above.method_26215();
            boolean atSolidOrFluid = !at.method_26215() || at.method_26204() instanceof class_2404;
            boolean belowSolid = !below.method_26215();

            if (aboveAir && atSolidOrFluid && belowSolid) {
                return y + 1; // 返回安全的传送位置（在固体方块上方）
            }
        }
        return minY; // 如果找不到安全位置，返回最低点
    }

    static int execute_command(class_2168 source, CommandContext<class_2168> context) throws CommandSyntaxException {
        var entity = source.method_44023();
        if (entity == null) {
            source.method_9213(class_2561.method_43470("需玩家执行！"));
            return 0;
        }

        String xStr = StringArgumentType.getString(context, "x");
        String yStr = StringArgumentType.getString(context, "y");
        String zStr = StringArgumentType.getString(context, "z");

        double x = parseCoordinate(xStr, entity.method_23317());
        double z = parseCoordinate(zStr, entity.method_23321());
        double y;

        class_3218 world = source.method_9225();

        // 检查 y 是否使用 ~ 符号
        if (yStr.equals("~")) {
            y = findSafeY(world, x, z);
        } else if (yStr.startsWith("~")) {
            y = parseCoordinate(yStr, entity.method_23318());
        } else {
            y = parseCoordinate(yStr, entity.method_23318());
        }

        entity.method_48105(world, x, y, z, new java.util.HashSet<>(), entity.method_36454(), entity.method_36455(), false);
        source.method_9226(() -> class_2561.method_43470("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }

    private static int execute(class_2168 source, CommandContext<class_2168> context) throws CommandSyntaxException {
        var player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("需玩家执行！"));
            return 0;
        }

        String xStr = StringArgumentType.getString(context, "x");
        String yStr = StringArgumentType.getString(context, "y");
        String zStr = StringArgumentType.getString(context, "z");

        double x = parseCoordinate(xStr, player.method_23317());
        double z = parseCoordinate(zStr, player.method_23321());
        double y;

        class_3218 dimension = class_2181.method_9289(context, "d");

        // 检查 y 是否使用 ~ 符号
        if (yStr.equals("~")) {
            y = findSafeY(dimension, x, z);
        } else if (yStr.startsWith("~")) {
            y = parseCoordinate(yStr, player.method_23318());
        } else {
            y = parseCoordinate(yStr, player.method_23318());
        }

        player.method_48105(dimension, x, y, z, new java.util.HashSet<>(), player.method_36454(), player.method_36455(), false);
        source.method_9226(() -> class_2561.method_43470("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }
}