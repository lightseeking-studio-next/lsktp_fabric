package lsk.lsktp;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import java.util.HashSet;

public class Lsktp implements ModInitializer {

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("x", DoubleArgumentType.doubleArg())
                            .then(class_2170.method_9244("y", DoubleArgumentType.doubleArg())
                                    .then(class_2170.method_9244("z", DoubleArgumentType.doubleArg())
                                            //   .executes(context -> teleportPlayer(context))
                                            .executes(context ->execute_command(context.getSource(),context))
                                    )
                            )
                    )
                    .requires(source -> source.method_9259(0)) // 设置权限等级
            );
        });

    }
    static int execute_command(class_2168 Source, CommandContext<class_2168> context){
        class_1297 entity =  Source.method_44023() ;

        double x = DoubleArgumentType.getDouble(context, "x");
        double y = DoubleArgumentType.getDouble(context, "y");
        double z = DoubleArgumentType.getDouble(context, "z");

        entity.method_48105(Source.method_9225(),x , y, z, new HashSet<>(), entity.method_36454(), entity.method_36455(),false);
//      return execute_command(Source, Radius, Player, Origin.getPos());
        context.getSource().method_9226(() -> class_2561.method_43470("传送至 " + x + ", " + y + ", " + z), false);

        return 1;
    }
}

