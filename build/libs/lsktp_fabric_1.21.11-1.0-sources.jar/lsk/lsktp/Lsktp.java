package lsk.lsktp;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2181;
import net.minecraft.class_2277;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class Lsktp implements ModInitializer {

    private static final SimpleCommandExceptionType INVALID_COORD = new SimpleCommandExceptionType(class_2561.method_43470("无效的坐标格式"));

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("pos", class_2277.method_9737())
                            .executes(context -> execute_command(context.getSource(), context))
                    )
            );
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("lsktp")
                    .then(class_2170.method_9244("d", class_2181.method_9288())
                            .then(class_2170.method_9244("pos", class_2277.method_9737())
                                    .executes(context -> execute(context.getSource(), context))
                            )
                    )
            );
        });
    }

    private static int findSafeY(class_3218 world, double x, double z) {
        class_2338 blockPos = new class_2338((int) x, 0, (int) z);
        int maxY = world.method_67393(net.minecraft.class_2902.class_2903.field_13197, blockPos);
        int minY = world.method_31607();

        // 从高处向下搜索第一个安全的 Y 坐标
        for (int y = maxY; y >= minY; y--) {
            class_2338 pos = new class_2338((int) x, y, (int) z);
            class_2680 above = world.method_8320(pos.method_10084());
            class_2680 at = world.method_8320(pos);
            class_2680 below = world.method_8320(pos.method_10074());

            // 检查上方是空气，当前位置是固体或流体，下方是固体
            boolean aboveAir = above.method_26215();
            boolean atSolidOrFluid = !at.method_26215() || at.method_26204() instanceof class_2404;
            boolean belowSolid = !below.method_26215();

            if (aboveAir && atSolidOrFluid && belowSolid) {
                return y + 1; // 返回安全的传送位置（在固体方块上方）
            }
        }
        return minY; // 如果找不到安全位置，返回最低点
    }
    //2026.2.10 21:38更新：原版y轴的～竟然不是安全坐标！而是原坐标！

    static int execute_command(class_2168 source, CommandContext<class_2168> context) throws CommandSyntaxException {
        class_1297 entity = source.method_44023();
        if (entity == null) {
            source.method_9213(class_2561.method_43470("需玩家执行！"));
            return 0;
        }

        class_243 pos = class_2277.method_9736(context, "pos");

        double x = pos.field_1352;
        double z = pos.field_1350;
        double y = pos.field_1351;

        class_3218 world = source.method_9225();
/*
        // 检查 y 是否使用 ~ 符号（通过检查原始输入）
        String input = context.getInput();
        String[] parts = input.split(" ");
        if (parts.length >= 3 && parts[2].equals("~")) {
            y = findSafeY(world, x, z);
        } else {
            y = pos.y;
        }
*/
        entity.method_48105(world, x, y, z, new java.util.HashSet<>(), entity.method_36454(), entity.method_36455(), false);
        source.method_9226(() -> class_2561.method_43470("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }

    private static int execute(class_2168 source, CommandContext<class_2168> context) throws CommandSyntaxException {
        class_1297 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("需玩家执行！"));
            return 0;
        }

        class_243 pos = class_2277.method_9736(context, "pos");

        double x = pos.field_1352;
        double z = pos.field_1350;
        double y = pos.field_1351;

        class_3218 dimension = class_2181.method_9289(context, "d");
/*
        // 检查 y 是否使用 ~ 符号（通过检查原始输入）
        String input = context.getInput();
        String[] parts = input.split(" ");
        if (parts.length >= 4 && parts[3].equals("~")) {
            y = findSafeY(dimension, x, z);
        } else {
            y = pos.y;
        }
        */


        player.method_48105(dimension, x, y, z, new java.util.HashSet<>(), player.method_36454(), player.method_36455(), false);
        source.method_9226(() -> class_2561.method_43470("传送至 " + String.format("%.2f", x) + ", " + String.format("%.2f", y) + ", " + String.format("%.2f", z)), false);

        return 1;
    }
}